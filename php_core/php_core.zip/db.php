<?php
$servername = "localhost";
$username = "ashik";
$password = "12345Ashik";
$db="my_application";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);

if (!$conn) {
	echo "connection Failed";
}

?>